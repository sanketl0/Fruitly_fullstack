from rest_framework import viewsets

from CIBPayment.models import TransactionStatus
from CIBPayment.serializers import TransactionStatusSerializer

from Logger import logger


class TransactionStatusViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = TransactionStatus.objects.all()
    serializer_class = TransactionStatusSerializer

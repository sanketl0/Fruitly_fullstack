from rest_framework import viewsets
from rest_framework.response import Response

from CIBPayment.models import BankServerSync
from CIBPayment.serializers import BankServerSyncSerializer

from Logger import logger


class BankServerSyncViewSet(viewsets.ViewSet):
    lookup_field = 'api'

    def list(self, request):
        logger.debug(f'-- API Call -- {request.path} | Headers: {request.headers} | Data: {request.data}')
        server_sync_objects = BankServerSync.objects.all()
        return Response(BankServerSyncSerializer(server_sync_objects, many=True).data)

    def retrieve(self, request, api):
        logger.debug(f'-- API Call -- {request.path} | Headers: {request.headers} | Data: {request.data}')
        server_sync_object = BankServerSync.objects.get(api=api)
        return Response(BankServerSyncSerializer(server_sync_object).data)

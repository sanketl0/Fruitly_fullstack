import datetime
import traceback

from django.utils import timezone

from rest_framework import viewsets
from rest_framework.decorators import api_view, action
from rest_framework.response import Response

from CIBPayment.models import BankServerSync

import BankAPI
from Logger import logger
from BankAPI.post_data_config import PostData


class BalanceViewSet(viewsets.ViewSet):

    @action(detail=False, url_path='Fetch')
    def fetch_balance(self, request):
        logger.debug(f'-- API Call -- {request.path} | Headers: {request.headers} | Data: {request.data}')

        # Get post data according to tenant
        post_data = PostData(client_name=request.tenant.name).get_for_balance_fetch()

        try:
            api = BankAPI.BalanceInquiryAPI(data=post_data)
            response = api.call()

            # Update the api being hit
            server_sync_object, created = BankServerSync.objects.get_or_create(api='BalanceInquiryAPI')
            server_sync_object.number_of_hits += 1
            server_sync_object.save()

            if 200 <= response.status_code <= 299:
                decrypted_response = api.decrypt_response_data(method='Basic')

                if decrypted_response.get("RESPONSE") == "FAILURE":
                    return Response(decrypted_response, status=500)
                else:
                    # Update a success hit
                    server_sync_object.last_successful_hit = timezone.now()
                    server_sync_object.save()

                    # Send last successful hit with response
                    decrypted_response['last_successful_hit'] = str(
                        timezone.localtime(server_sync_object.last_successful_hit))

                    return Response(decrypted_response)
            else:
                logger.error(f"Error response: {response.text} | status_code: {response.status_code}")
                return Response(response.json(), status=response.status_code)

        except Exception as e:
            logger.error(traceback.format_exc())
            return Response(str(e), status=500)

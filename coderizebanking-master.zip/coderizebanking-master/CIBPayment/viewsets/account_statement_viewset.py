import datetime
import traceback
import pytz

from django.utils import timezone
from rest_framework import viewsets
from rest_framework.decorators import api_view, action
from rest_framework.response import Response

from CIBPayment.models import AccountStatement, BankServerSync
from CIBPayment.serializers import AccountStatementSerializer, AccountStatementUpdateStatementSerializer

import BankAPI
from Logger import logger
from BankAPI.post_data_config import PostData


class AccountStatementViewSet(viewsets.ViewSet):
    # queryset = AccountStatement.objects.all()
    # serializer_class = AccountStatementSerializer

    """ GET APIs """

    def list(self, request):
        if len(self.request.query_params) > 0:
            query_parameters = {_: self.request.query_params.get(_) for _ in self.request.query_params}
        else:
            query_parameters = {}

        queryset = AccountStatement.objects.filter(**query_parameters)
        return Response(AccountStatementSerializer(queryset, many=True).data)

    @action(detail=False, url_path=r'CreditOnly/BetweenDates/(?P<from_date>[^\.]+)/(?P<to_date>[^\.]+)')
    def get_credit_between_dates(self, request, from_date, to_date):
        """
        For Reconciliation
        Return only those transactions which have not been reconciled
        """
        queryset = AccountStatement.objects.filter(TYPE='CR',
                                                   VALUEDATE__range=(from_date, to_date))
        return Response(AccountStatementSerializer(queryset, many=True).data)

    @action(detail=False, url_path='TestGetBetweenDates')
    def test_get_between_dates(self, request):
        logger.debug(f'-- API Call -- {request.path} | Headers: {request.headers} | Data: {request.data}')

        post_data = PostData(client_name=request.tenant.name)
        # post_data = {
        #     "AGGRID": "OTOE0480",
        #     "CORPID": "582735465",
        #     "USERID": "NILESHSH",
        #     "URN": "SR213835043",
        #     "ACCOUNTNO": "346105001227",
        #     "FROMDATE": '28-02-2022',
        #     "TODATE": '28-02-2022'
        # }
        api = BankAPI.AccountStatementAPI(
            data=post_data.get_for_account_statement(from_date='11-03-2022', to_date='11-03-2022'))

        response = api.call()

        decrypted_response = api.decrypt_response_data(method='Hybrid')

        return Response(decrypted_response)

    @action(detail=False, url_path='UpdateStatement')
    def update_table(self, request):
        """ To update new account statements into the database """
        logger.debug(f'-- API Call -- {request.path} | Headers: {request.headers} | Data: {request.data}')

        # If we pass TODATE, then it will take TODate otherwise it will take current date
        if request.GET.get('TODATE'):
            try:
                current_date = datetime.datetime.strptime(request.GET.get('TODATE'), "%Y-%m-%d").date()
            except Exception as e:
                return Response('Pass to date in YYYY-MM-DD format. {e}', status=400)
        else:
            # Get the current date
            current_date = datetime.datetime.now(pytz.timezone('Asia/Kolkata')).date()

        if request.GET.get('FROMDATE'):
            try:
                last_date = datetime.datetime.strptime(request.GET.get('FROMDATE'), "%Y-%m-%d").date()
            except Exception as e:
                return Response('Pass from date in YYYY-MM-DD format. {e}', status=400)
        else:
            # Get the last date of account statement
            transaction_dates = AccountStatement.objects.values_list('TXNDATE', flat=True)
            if len(transaction_dates) == 0:
                last_date = current_date
            else:
                last_date = max(transaction_dates).date()

        # Here we are getting formatting the data to be send to Bank's APIs
        post_data = PostData(client_name=request.tenant.name)
        post_data = post_data.get_for_account_statement(from_date=str(last_date.strftime("%d-%m-%Y")),
                                                        to_date=str(current_date.strftime("%d-%m-%Y")))
        # post_data = {
        #     "AGGRID": "OTOE0480",
        #     # "AGGRNAME": "FRUITLY",
        #     "CORPID": "582735465",
        #     "USERID": "NILESHSH",
        #     "URN": "SR213835043",
        #     "ACCOUNTNO": "346105001227",
        #     "FROMDATE": str(last_date.strftime("%d-%m-%Y")),
        #     "TODATE": str(current_date.strftime("%d-%m-%Y"))
        # }

        old_transaction_ids = AccountStatement.objects.values_list('TRANSACTIONID', flat=True)

        try:
            api = BankAPI.AccountStatementAPI(data=post_data)
            response = api.call()

            # Update last hit date
            server_sync_object, created = BankServerSync.objects.get_or_create(api='AccountStatementAPI')
            server_sync_object.number_of_hits += 1
            server_sync_object.save()

            # Check 1 if response code is not in 200
            if response.status_code >= 300:
                return Response(response.json(), status=response.status_code)

            decrypted_response = api.decrypt_response_data(method='Hybrid')

            # Check 2 if decrypted response return success
            if decrypted_response.get('RESPONSE') in ('FAILURE', 'Failure'):
                return Response(decrypted_response, status=400)

            # If all checks are complete, then process records

            # Update a success hit
            server_sync_object.last_successful_hit = timezone.now()
            server_sync_object.save()

            unique_records = []
            if isinstance(decrypted_response['Record'], list):
                for record in decrypted_response['Record']:
                    # Ignore records which are already there for last date
                    if record['TRANSACTIONID'] in old_transaction_ids:
                        continue

                    # Update account number in all fields
                    record['ACCOUNTNO'] = decrypted_response['ACCOUNTNO']
                    # Update user details
                    record['created_by'] = str(request.user)
                    # Remove commas from AMOUNT and BALANCE
                    record['AMOUNT'] = record['AMOUNT'].replace(",", "")
                    record['BALANCE'] = record['BALANCE'].replace(",", "")

                    unique_records.append(record)
            else:
                record = decrypted_response['Record']
                if record['TRANSACTIONID'] in old_transaction_ids:
                    pass
                else:
                    # Update account number in all fields
                    record['ACCOUNTNO'] = decrypted_response['ACCOUNTNO']
                    # Update user details
                    record['created_by'] = str(request.user)
                    # Remove commas from AMOUNT and BALANCE
                    record['AMOUNT'] = record['AMOUNT'].replace(",", "")
                    record['BALANCE'] = record['BALANCE'].replace(",", "")

                    unique_records.append(record)

            if len(unique_records) > 0:
                # Save the data to database
                serializer = AccountStatementUpdateStatementSerializer(data=unique_records, many=True)
                if serializer.is_valid():
                    serializer.save()

                    # Update a success hit
                    server_sync_object.last_successful_hit = timezone.now()
                    server_sync_object.save()

                    return Response({
                        "message": f"{len(unique_records)} New Records found and updated",
                        "last_successful_hit": str(timezone.localtime(server_sync_object.last_successful_hit)),
                        "data": serializer.data
                    })

                else:
                    return Response(serializer.errors, status=400)
            else:
                return Response({
                    "message": "No new records found.",
                    "last_successful_hit": str(timezone.localtime(server_sync_object.last_successful_hit)),
                    "data": []
                })

        except Exception as e:
            logger.error(traceback.format_exc())
            return Response(str(e), status=500)

    @action(detail=False, url_path='SplitUnsplitRemarks')
    def split_unsplit_remarks(self, request):
        statement_rows = AccountStatement.objects.filter(remark_subtype__isnull=True)

        total_rows = len(statement_rows)
        for i, statement_row in enumerate(statement_rows):
            statement_row.split_remark()
            statement_row.save()

            print(f"[{i}/{total_rows}] - {i / total_rows * 100 :.2f}% - Done", end='\r')
        print("")

        return Response("Split Done")

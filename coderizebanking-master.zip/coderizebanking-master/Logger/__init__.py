from .logger_obj import Logger
from .logger_view import get_server_log

logger = Logger(name='FruitlyPaymentsLog')

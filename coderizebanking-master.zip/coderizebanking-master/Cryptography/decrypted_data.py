import json
import base64

from .session_key import SessionKey
# from .data_to_encrypt import DataToEncrypt

import json
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP, PKCS1_v1_5
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad, unpad
import base64


class DecryptedData:
    """ Decrypted response from CIB Payments API """

    def __init__(self, data=None):
        self.decrypted_data = data
        self.encrypted_data = None

    def __str__(self):
        return str(self.decrypted_data)

    def to_dict(self):
        """ Convert to dictionary from json"""
        return json.loads(self.decrypted_data)

    def encrypt_hybrid(self, public_key_path):
        # Generate random number and encrypt it using key
        session_key = SessionKey()
        session_key.generate()
        encryptedKey = session_key.encrypt(public_key_path=public_key_path)

        # Generate IV and encrypt it using key
        iv = SessionKey()
        iv.generate()
        iv.encrypt(public_key_path=public_key_path)

        # Encrypt the response data
        request_data = json.dumps(self.decrypted_data).encode('utf-8')
        cipher = AES.new(session_key.value, AES.MODE_CBC, iv=iv.value)

        encrypted_data = cipher.encrypt(pad(request_data, AES.block_size))
        encrypted_data = base64.b64encode(encrypted_data).decode('utf-8')

        # Fill all these values in response to return
        return_dict = dict()
        return_dict['encryptedKey'] = encryptedKey
        return_dict['encryptedData'] = encrypted_data
        return_dict['iv'] = base64.b64encode(iv.value).decode('utf-8')

        return return_dict

# if __name__ == '__main__':
#     # Sample Data
#     data = "vewnSj5v+gLvTaAhb0JywLRfNcpuHv0Ks6hMmtyoXKZMCab/++nFhA1G4egmjX3w5kYtW2HP+abTwgbQLdsk6mH+GnCc4WxtU0CD+XRxZPmnkCA2Is0Owp60xRrz/uefaHWsl0sNqaub4Oi+4lMBSGCeCtTPZtkEpwloKjOVfwbOOYGa73Rd8ToPoLmHgC5VFlICKmLAFr+A4KW6jHVcTELMlfTHB5Lb5hMVbC7mv2G3XQp2sLGoYzRSutDdmvY9DSRF0t32wSpB8q0TLh7OpCfAkZ5pK2I3JOyLjpuQrGqzuh5tF8Wyicjo+9a4gIsS4dMFeDB/k2F4iwNDaPsrBapXKcycoC3ys0AVZAxWpMynVaFfBkxGUuqxMSrE4UGbAoeS0x18HrEwHI55y6JveM7Wyy7fOPXduP+d+Y6LkBoVmhVMYw9xztOpKp0LGgg5seiZf9K5mQTF/p9CJhqpidK/ez+LedfhM/7hPljAKf4jG6zfi0Kc265W8qWt/bsrbB7nra8vJl+n/N40ChL9RGvMmCFbe6DNNGVmPXTScr9j8ITCGDdoZc0/KYSFNYPflQ+0SDM+djo7reXtmHrVFVE0iQprdXN1b/HjNhNBAJONE/UkImkaxXLq7V0aMi7tyABffiovc9ru8Plr/GQxwzBU7aob0KwxuNVS1qlITRE="
#
#     enc = EncryptedResponse(data)
#     private_key_path = r"E:\CodeRizer_Work\Projects\FruitlyPayments\keys\privkey.pem"
#
#     dec = enc.decrypt(private_key_path)
#     print(dec)
